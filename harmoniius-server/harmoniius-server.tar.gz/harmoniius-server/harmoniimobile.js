var timer = null; // timer for voting 
var timeLeft;
var songDetails;

var list;
var playlist;
var rank1,
	rank2,
	rank3;

$(function(){
// All songs to be played
	songDetails = new Array(["Super Bass", "Nicki Minaj", "Pink Friday", "200", "5"], ["Party In The U.S.A.", "Miley Cyrus", "The Time of Our Lives", "202", "3"], ["Pop", "*NSYNC", "Greatest Hits", "238", "4"], ["Don't Stop Believin'", "Journey", "Greatest Hits", "248", "2"], ["The Time (Dirty Bit)", "The Black Eyed Peas", "The Beginning", "307", "1"]);	

	playlist = new Array(["Party In The U.S.A.", "Miley Cyrus", "84", "1"], ["Ignition Remix", "R. Kelly", "10", "2"], ["Holiday", "Madonna", "6", "3"], ["Hypnotize", "The Notorius B.I.G.", "16", "3"], ["Auto Rock", "Mogwai", "19", "2"], ["Pop", "*NSYNC", "65", "1"], ["This is How We Do It (Re-Recorded/Remastered)", "Montell Jordan", "12", "3"], ["Don't Stop Believin'", "Journey", "73", "1"], ["Jessie's Girl", "Rick Springfield", "15", "2"], ["Rock With You", "Michael Jackson", "18", "3"], ["Domino", "Jessie J", "24", "2"], ["The Time (Dirty Bit)", "The Black Eyed Peas", "58", "1"]);
	list = new Array(["N/A", "N/A", "0"], ["N/A", "N/A", "0"], ["N/A", "N/A", "0"], ["Party In The U.S.A.", "Miley Cyrus", "84"], ["Ignition Remix", "R. Kelly", "10"], ["Holiday", "Madonna", "6"], ["Hypnotize", "The Notorius B.I.G.", "16"], ["Auto Rock", "Mogwai", "19"], ["Pop", "*NSYNC", "65"], ["This is How We Do It (Re-Recorded/Remastered)", "Montell Jordan", "12"], ["Don't Stop Believin'", "Journey", "73"], ["Jessie's Girl", "Rick Springfield", "15"], ["Rock With You", "Michael Jackson", "18"], ["Domino", "Jessie J", "24"], ["The Time (Dirty Bit)", "The Black Eyed Peas", "58"]);
	rank1 = new Array(["N/A", "N/A", "0"], ["Party In The U.S.A.", "Miley Cyrus", "84", "1"], ["Pop", "*NSYNC", "65", "1"], ["Don't Stop Believin'", "Journey", "73", "1"], ["The Time (Dirty Bit)", "The Black Eyed Peas", "58", "1"]);
	rank2 = new Array(["N/A", "N/A", "0"], ["Ignition Remix", "R. Kelly", "10", "2"], ["Auto Rock", "Mogwai", "19", "2"], ["Jessie's Girl", "Rick Springfield", "15", "2"], ["Domino", "Jessie J", "24", "2"]);
	rank3 = new Array(["N/A", "N/A", "0"], ["Holiday", "Madonna", "6", "3"], ["Hypnotize", "The Notorius B.I.G.", "16", "3"], ["This is How We Do It (Re-Recorded/Remastered)", "Montell Jordan", "12", "3"], ["Rock With You", "Michael Jackson", "18", "3"]);

	showNowPlaying();
	//showVotingResults();
	showChoices();
//	timeLeft = new Array("49", "10", "14", "8", "5");
//	beginTimer();

	$(".song-choice").click(function() {
		for (var i = 1; i < 4; i++) {
			if ($("#song-" + i).hasClass("voted")) {
				$("#song-" + i).removeClass("voted");
			}
		}
		$("#" + this.id).addClass("voted");
	});
});

// Begins timer
function beginTimer() {
	if (timer == null) {
		timer = setInterval(countdown, 1000);
		if ($("#album-art").html() == ""){
			showNowPlaying();	
		} 
		if ($("#song-1 > .song-title").html() == "") {
			showChoices();
			$(".song-choice").removeClass("voted");
		}
		//if ($("#timer").hasClass("warning")) {
			
	//	}
		if ($("#place1 .song-title").html() == "") {
			showVotingResults();
		}
	}
}

// Counts down until end of voting 
function countdown() {
	// Placeholder timeLeft is set in index.html
	var min = parseInt(timeLeft/*[0]*/ / 60);
	var sec = timeLeft/*[0]*/ % 60; 
	if (sec < 10) {
		sec = '0' + sec;
	}
	if (timeLeft/*[0]*/ == 45) {
		$("#timer").addClass("warning");
	}
	$("#time").text(min + ":" + sec); // updates html 
	
	// Stops timer
	if (timeLeft/*[0]*/ == 0) {
		$("#time").text("0:00"); // updates html 
		if (timeLeft == 0) {
			clearInterval(timer);
			//timeLeft.shift();
			$("#timer").removeClass("warning");
			songDetails.shift();
			rank1.shift();
			rank2.shift();
			rank3.shift();
			for (var x = 0; x < 3; x++) {
				playlist.shift();
				list.shift();
			}
			removeContent();			
		}
		if (songDetails.length != 0) {
			// When new song loads
			timer = null;
			beginTimer();
		}
	}
	timeLeft/*[0]*/--;
}

function removeContent() {
	$(".song-title").empty();
	$(".artist-name").empty();
	$(".album-title").empty();
	$("#album-art").empty();
	$(".percent").empty();
}

// Retrieves "Now Playing" song information and prints to page
function showNowPlaying() {
	
	$("#song-info > .song-title").html(songDetails[0][0]);
	$("#song-info > .artist-name").html(songDetails[0][1]);
	$("#song-info > .album-title").html(songDetails[0][2]);
	
	var img = document.createElement("img");
	var filename =  parseInt(songDetails[0][4]);
	$(img).attr("src", "albums/" + filename + ".jpg");
	$("#album-art").append($(img));
	timeLeft = songDetails[0][3];
	beginTimer();
}

// Retrieves and prints voting results
function showVotingResults() {
	// voteResults is placeholder for retrieved voting results from server
	// var voteResults = new Array(["December", "Weezer", "Maladroit", "56%"], ["Black Hole Sun", "Soundgarden", "Superunknown", "38%"], ["Butterfly", "Weezer", "Pinkerton", "6%"]);

	// Creates unordered lists for all three songs
	//for (var i = 1; i < 4; i++) {
		//var a = "#place" + list[0][3];
		//var b = list[1][3];
		//var c = list[2][3];

		$("#place1 .song-title").html(rank1[0][0]);
		$("#place1 .artist-name").html(rank1[0][1]);
		$("#place1 .percent").html(rank1[0][2] + "%");
		
		$("#place2 .song-title").html(rank2[0][0]);
		$("#place2 .artist-name").html(rank2[0][1]);
		$("#place2 .percent").html(rank2[0][2] + "%");

		$("#place3 .song-title").html(rank3[0][0]);
		$("#place3 .artist-name").html(rank3[0][1]);
		$("#place3 .percent").html(rank3[0][2] + "%");
		/*for (var i = 1; i < 4; i++ ) {
			if (list[0][3] == i) {
				$("#place" + i + " .song-title").html(list[0][0]);
				$("#place" + i + " .artist-name").html(list[0][1]);
				$("#place" + i  + " .percent").html(list[0][2] + "%");
			} else if (list[1][3] == i) {
				$("#place" + i + " .song-title").html(list[1][0]);
				$("#place" + i + " .artist-name").html(list[1][1]);
				$("#place" + i  + " .percent").html(list[1][2] + "%");
			} else {
				$("#place" + i + " .song-title").html(list[2][0]);
				$("#place" + i + " .artist-name").html(list[2][1]);
				$("#place" + i + " .percent").html(list[2][2] + "%");
			}
		}*/

		/*	} else if (list[0][3] == 2) {
				$("#place2 .song-title").html(list[0][0]);
				$("#place2 .artist-name").html(list[0][1]);
				$("#place2 .percent").html(list[0][2] + "%");
			} else {
				$("#place3 .song-title").html(list[0][0]);
				$("#place3 .artist-name").html(list[0][1]);
				$("#place3 .percent").html(list[0][2] + "%");
			}

			if (list[1][3] == 1) {
				$("#place1 .song-title").html(list[1][0]);
				$("#place1 .artist-name").html(list[1][1]);
				$("#place1 .percent").html(list[1][2] + "%");
			} else if (list[1][3] == 2) {
				$("#place2 .song-title").html(list[1][0]);
				$("#place2 .artist-name").html(list[1][1]);
				$("#place2 .percent").html(list[1][2] + "%");
			} else {
				$("#place3 .song-title").html(list[1][0]);
				$("#place3 .artist-name").html(list[1][1]);
				$("#place3 .percent").html(list[1][2] + "%");
			}
			
			if (list[2][3] == 1) {
				$("#place1 .song-title").html(list[2][0]);
				$("#place1 .artist-name").html(list[2][1]);
				$("#place1 .percent").html(list[2][2] + "%");
			} else if (list[2][3] == 2) {
				$("#place2 .song-title").html(list[2][0]);
				$("#place2 .artist-name").html(list[2][1]);
				$("#place2 .percent").html(list[2][2] + "%");
			} else {
				$("#place3 .song-title").html(list[2][0]);
				$("#place3 .artist-name").html(list[2][1]);
				$("#place3 .percent").html(list[2][2] + "%");
			}
	//	}*/

/*		if (a > b) {
			if (c > a) {
			
				$("#place1 .song-title").html(list[2][0]);
				$("#place1 .artist-name").html(list[2][1]);
				$("#place1 .percent").html(list[2][2] + "%");
				
				$("#place2 .song-title").html(list[1][0]);
				$("#place2 .artist-name").html(list[1][1]);
				$("#place2 .percent").html(list[1][2] + "%");
			
				$("#place3 .song-title").html(list[0][0]);
				$("#place3 .artist-name").html(list[0][1]);
				$("#place3 .percent").html(list[0][2] + "%");
			} else /*a > c {*/
			/*	if (b > c) {
					$("#place1 .song-title").html(list[0][0]);
					$("#place1 .artist-name").html(list[0][1]);
					$("#place1 .percent").html(list[0][2] + "%");
					
					$("#place2 .song-title").html(list[1][0]);
					$("#place2 .artist-name").html(list[1][1]);
					$("#place2 .percent").html(list[1][2] + "%");

					$("#place3 .song-title").html(list[2][0]);
					$("#place3 .artist-name").html(list[2][1]);
					$("#place3 .percent").html(list[2][2] + "%");
				} else /* b < c  {*/
			/*		$("#place1 .song-title").html(list[0][0]);
					$("#place1 .artist-name").html(list[0][1]);
					$("#place1 .percent").html(list[0][2] + "%");
					
					$("#place2 .song-title").html(list[2][0]);
					$("#place2 .artist-name").html(list[2][1]);
					$("#place2 .percent").html(list[2][2] + "%");
				
					$("#place3 .song-title").html(list[1][0]);
					$("#place3 .artist-name").html(list[1][1]);
					$("#place3 .percent").html(list[1][2] + "%");
				}
			}
		} else if (b > a) {
			if (a > c) {
				$("#place1 .song-title").html(list[1][0]);
				$("#place1 .artist-name").html(list[1][1]);
				$("#place1 .percent").html(list[1][2] + "%");
				
				$("#place2 .song-title").html(list[0][0]);
				$("#place2 .artist-name").html(list[0][1]);
				$("#place2 .percent").html(list[0][2] + "%");
			
				$("#place3 .song-title").html(list[2][0]);
				$("#place3 .artist-name").html(list[2][1]);
				$("#place3 .percent").html(list[2][2] + "%");
			} else { // a < c
				$("#place1 .song-title").html(list[1][0]);
				$("#place1 .artist-name").html(list[1][1]);
				$("#place1 .percent").html(list[1][2] + "%");
				
				$("#place2 .song-title").html(list[2][0]);
				$("#place2 .artist-name").html(list[2][1]);
				$("#place2.percent").html(list[2][2] + "%");
			
				$("#place3 .song-title").html(list[0][0]);
				$("#place3 .artist-name").html(list[0][1]);
				$("#place3 .percent").html(list[0][2] + "%");
			}
		} else {
			$("#place1 .song-title").html(list[2][0]);
			$("#place1 .artist-name").html(list[2][1]);
			$("#place1 .percent").html(list[2][2] + "%");

			$("#place2 .song-title").html(list[0][0]);
			$("#place2 .artist-name").html(list[0][1]);
			$("#place2 .percent").html(list[0][2] + "%");
		
			$("#place3 .song-title").html(list[1][0]);
			$("#place3 .artist-name").html(list[1][1]);
			$("#place3 .percent").html(list[1][2] + "%");
		}
		//$("#place" + i + ".artist-name").html(list[i][1]);
	//}
		//var rank;
		//if (i == 0) {
		

			//rank = "first";
		//} else if (i == 1) {
		//	rank = "second";
		//} else {
		//	rank = "third";
		//}
		//$("#" + rank).append(createSongDetails(voteResults[i], "results"));//rank));
		
		// Adding percentage to list
		//var p = document.createElement("p");
		//p.innerHTML = voteResults[i][3]; // percent
		//$(p).addClass("percent");
		//$("#" + rank).append($(p));*/

}

// Retrieves and prints song choices to vote for
function showChoices() {
	// songChoices is placeholder for retrieved triplet of song choices
	//var songChoices = new Array(["You'll Never Walk Alone", "TOKYO SKA PARADISE", "PARADISE BLUE"], ["Boring Machines Disturbs ", "Mogwai", "Happy Songs for Happy People"], ["Californication", "Red Hot Chili Peppers", "Californication"]);
	
	// Creates ul for 3 song choices
	for (var i = 1; i < 4; i++) {
		$("#song-"+ i + " > .song-title").html(playlist[i - 1][0]);
		$("#song-"+ i + " > .artist-name").html(playlist[i - 1][1]);
	}
}


// Creates unordered list for song detail (incl. song, artist, album names)
function createSongDetails(detailArray, idName) {
	var ul = document.createElement("ul");
	ul.id = idName;
	if (idName == "song-info") {
		for (var i = 0; i < 3; i++){
			var li = document.createElement("li");
			li.innerHTML = detailArray[i];
			var name;
			if (i == 0) {
				name = "song-title";
			} else if (i == 1) {
				name = "artist-name";
			} else {
				name = "album-title";
			} 
			$(li).addClass(name);
			$(ul).append($(li));
		}
	} else {
		for (var i = 0; i < 2; i++){
			var li = document.createElement("li");
			li.innerHTML = detailArray[i];
			var name;
			if (i == 0) {
				name = "song-title";
			} else if (i == 1) {
				name = "artist-name";
			} else {
				name = "album-title";
			} 
			$(li).addClass(name);
			$(ul).append($(li));
		}
	}
	return ul;
}


/// eMusic API ///
/* --------------------------- */

// Gets artist id from eMusic API
function getArt(id) { 
    // Find artist
   $.ajax({

        url: "http://api.emusic.com/track/search",
        data: {            
            format: "JSONP",
            artistId: id, 
            apiKey: "b9e2m6p69fnr6ycen25kydv8"
        },
        dataType: "jsonp",
        success: function(data) {
            var i = 0;
            var track = data.tracks[i];
            while (i < data.tracks.length) {
               	if (track.name == songDetails[0][0]) {
	            	var img = document.createElement("img");
	              	$(img).attr("src", track.album.image);
	            	$("#album-art").append($(img)); 


               //  var id = artist.id;
                 
                 //getAlbum(id, songDetails);
                }
                  i++;
                  artist = data.tracks[i];
            }
        },

        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest + ":" + textStatus + ":" + errorThrown);
        } 
    });    

}

// Gets album image from eMusic API
function getAlbum(id, songDetails) {
	// Find album
	$.ajax( {

	    url: "http://api.emusic.com/album/search",
	    data: { 
	        format: "JSONP",
	        artistId: id,
	        imageSize: "small",
	        apiKey: "b9e2m6p69fnr6ycen25kydv8"
	    },
	    dataType: "jsonp",
	    success: function(data) {
	        var i = 0;
	        var album = data.albums[i];
	        while (i < data.albums.length) {
	          if (album.name == songDetails[2]) {
	              var img = document.createElement("img");
	              $(img).attr("src", album.image);
	            	$("#album-art").append($(img));
	          }
	          i++;
	          album = data.albums[i];
	        }                                  
	    },

	    error: function(XMLHttpRequest, textStatus, errorThrown) {
	        alert(XMLHttpRequest + ":" + textStatus + ":" + errorThrown);
	    } 
	});   
}


