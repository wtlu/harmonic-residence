CREATE USER 'harmonicresidence'@'localhost' IDENTIFIED BY 'SkJuqKQY4alu';
GRANT ALL PRIVILEGES ON *.* TO 'harmonicresidence'@'localhost' WITH GRANT OPTION; 
CREATE USER 'harmonicresidence'@'%' IDENTIFIED BY 'SkJuqKQY4alu';
GRANT ALL PRIVILEGES ON *.* TO 'harmonicresidence'@'%' WITH GRANT OPTION;